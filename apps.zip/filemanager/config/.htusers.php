<?php 
	// ensure this file is being included by a parent file
	if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
	$GLOBALS["users"]=array(
	array('admin','$2a$08$8Fcz8yjVGw5A30Po.o3J7OouGDHaOpt0kNB1v.1GwvZj0vkajCXaq','/etc/sentora/panel/','http://localhost','1','','7',1),
); 
?>